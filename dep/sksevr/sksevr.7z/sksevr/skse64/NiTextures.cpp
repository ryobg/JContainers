#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00CAEF60);
RelocAddr<_LoadTexture> LoadTexture(0x012CE8A0);