#pragma once

void Hooks_Debug_Init(void);
void Hooks_Debug_Commit(void);
