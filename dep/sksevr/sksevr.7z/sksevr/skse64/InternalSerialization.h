#pragma once

UInt8 ResolveModIndex(UInt8 modIndexIn);
UInt16 ResolveLightModIndex(UInt16 modIndexIn);
void Init_CoreSerialization_Callbacks();
