#include "GameVR.h"

RelocPtr <BSOpenVR *> g_openVR(0x02FEB9B0);
RelocAddr<_HmdMatrixToNiTransform> HmdMatrixToNiTransform(0x00C57700);