#include "skse64/NiSerialization.h"
