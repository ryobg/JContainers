#include "skse64/BSModelDB.h"

// 206875324DD3C045FB854CB2889AFBCA94C7790B+89
RelocPtr <BSModelDB::BSModelProcessor*> g_TESProcessor(0x01F5D910);
