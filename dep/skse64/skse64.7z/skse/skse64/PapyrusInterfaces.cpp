#include "skse64/PapyrusInterfaces.h"

// B085C9577FC3BACF4719EF79E3613E2327537C10+4F
RelocPtr <IObjectHandlePolicy*> g_objectHandlePolicy(0x0326ACB0);
