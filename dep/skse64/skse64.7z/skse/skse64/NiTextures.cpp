#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00CA3B50);
RelocAddr<_LoadTexture> LoadTexture(0x013BA220);
