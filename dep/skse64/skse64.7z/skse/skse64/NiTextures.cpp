#include "skse64/NiTextures.h"

RelocAddr<_CreateSourceTexture> CreateSourceTexture(0x00D2F140);
RelocAddr<_LoadTexture> LoadTexture(0x01480030);
