#pragma once

void Hooks_ObScript_Init();
void Hooks_ObScript_Commit();
