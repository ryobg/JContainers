#pragma once

void Hooks_Diagnostics_Commit(void);